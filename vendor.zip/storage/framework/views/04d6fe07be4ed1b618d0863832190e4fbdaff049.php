

<?php $__env->startSection('content'); ?>
<section class="top-title">
    <div class="top-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="top-page-heading">
                        <h1>SERVICES</h1>
                        <p class="sub-title">Service at the highest level!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li>
                            /Service
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Top Title -->
<!-- Start Services Area -->
<section class="services-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="template-title center">
                    <h1>Our Services</h1>
                    <span>Our Services</span>
                    <p class="subtitle">
                        Our aim is to fill a gap in niche market of Trade
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="services-item center">
                    <div class="services-image">
                        <img src="<?php echo e(asset('uploads/event_thumbnail/' . $service->thumbnail)); ?>">
                    </div>
                    <div class="services-content">
                        <h4><a href="<?php echo e(route('service-home', ['slug' => $service->event_slug])); ?>"><?php echo e($service->event_name); ?></a></h4>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/pages/service.blade.php ENDPATH**/ ?>