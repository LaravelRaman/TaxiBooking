

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-6">
                        <h3>Vehicle</h3>
                        <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item">Vehicle</li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle')); ?>">Vehicles</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                        <div class="col-6">
                            <h5> Vehicles </h5>
                        </div>
                        <div class="col-6">
                            <a href="<?php echo e(url('admin/add-vehicle')); ?>"><button class="btn btn-primary" style="float:right;">Add New Vehicle</button></a>
                        </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong class><?php echo e($message); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                    <div class="table-responsive">
                        <table class="stripe" id="example-style-8">
                        <thead>
                            <tr>
                            <th>Thumbnail</th>
                            <th>Vehicle Title</th>
                            <th>Make and Model</th>
                            <th>Status</th>
                            <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img src="<?php echo e(asset('uploads/vehicle/'.$vehicle->vehicle_thumbnail)); ?>" alt="" srcset="" style="height: 188px; 270px;"></td>
                                    <td><?php echo e(!empty($vehicle->vehicle_name)?$vehicle->vehicle_name:'NA'); ?></td>
                                    <td>
                                        Make: <?php echo e(!empty($vehicle->vehicle_make)?$vehicle->vehicle_make:'NA'); ?><br/>
                                        Model: <?php echo e(!empty($vehicle->vehicle_model)?$vehicle->vehicle_model:'NA'); ?>

                                    </td>
                                    <td>
                                        <?php echo e(!empty($vehicle->status)?$vehicle->status:'NA'); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('admin/edit-vehicle',$vehicle->vehicle_slug)); ?>"><button class="btn btn-warning" style="margin-bottom:2px;"><i class="fa fa-pencil"></i></button> </a>
                                        <a href="<?php echo e(url('admin/delete-vehicle',$vehicle->vehicle_slug)); ?>"><button class="btn btn-danger"><i class="fa fa-trash"></i></button></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                            <th>Thumbnail</th>
                            <th>Vehicle Title</th>
                            <th>Make and Model</th>
                            <th>Status</th>
                            <th>Action</th>
                            </tr>
                        </tfoot>
                        </table>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/admin/vehicle/vehicle.blade.php ENDPATH**/ ?>