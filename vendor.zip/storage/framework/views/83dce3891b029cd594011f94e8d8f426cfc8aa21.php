

<?php $__env->startSection('content'); ?>
<section class="top-title">
    <div class="top-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="top-page-heading">
                        <h1>EVENTS</h1>
                        <p class="sub-title">Latest news from Prodirve</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <li>
                            <a href="#">Home</a>
                        </li>
                        <li>
                            /Event
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="main-post">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-sm-6">
                <article class="post">
                    <div class="featured-image">
                        <div class="item active">
                            <?php if(Storage::disk('public')->exists('uploads/event_thumbnail/' . $event->thumbnail)): ?>
                                <img src="<?php echo e(asset('uploads/event_thumbnail/' . $event->thumbnail)); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('frontend/images/blog/01.jpg')); ?>" alt="Image">
                            <?php endif; ?>
                        </div>
                    </div>							
                    <div class="entry-content">
                        <div class="entry-post-title">
                            <h4 class="post-title"><a href="#"><?php echo e($event->event_name); ?></a></h4>
                        </div>
                        <ul>
                            <li class="author">
                                <a href="#"><img src="<?php echo e(asset('frontend/images/icon/date.png')); ?>" alt="">From : <?php echo e(date('d F Y',strtotime($event->from_date))); ?></a>
                            </li>
                            <li class="date">
                                <a href="#"><img src="<?php echo e(asset('frontend/images/icon/date.png')); ?>" alt="">To : <?php echo e(date('d F Y',strtotime($event->to_date))); ?></a>
                            </li>
                        </ul>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="pagination-area">
                    <ul>
                        <li class="prev ">
                            <a href="#" class="waves-effect" title="">
                                <img src="<?php echo e(asset('frontend/images/icon/prev.png')); ?>" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="#" class="waves-effect" title="">1</a>
                        </li>
                        <li class="active"><a href="#" class="waves-effect" title="">2</a></li>
                        <li><a href="#" class="waves-effect" title="">3</a></li>
                        <li><a href="#" class="waves-effect" title="">...</a></li>
                        <li><a href="#" class="waves-effect" title="">22</a></li>
                        <li class="next">
                            <a href="#" class="waves-effect" title="">
                                <img src="<?php echo e(asset('frontend/images/icon/next.png')); ?>" alt="">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/pages/event.blade.php ENDPATH**/ ?>