

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-6">
                        <h3>Edit Vehicle</h3>
                        <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item">Vehicle</li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle')); ?>">Vehicles</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle-type')); ?>">Edit Vehicle</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-6">
                                    <h5> Edit Vehicle </h5>
                                </div>
                                <div class="col-6">
                                    <a href="<?php echo e(url('admin/vehicle')); ?>"><button class="btn btn-danger" style="float:right;">Back</button></a>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <form class="theme-form" action="<?php echo e(url('/admin/update-vehicle',$vehicle->vehicle_slug)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type</label><span style="color: red; margin:4px;">*</span>
                                        <select class="form-control" id="vehicle_type" type="text" name="vehicle_type" aria-describedby="emailHelp" placeholder="Enter Vehicle Name" required>
                                            <option value="">-- no type selected --</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->id); ?>" <?php echo e($type->id == $vehicle->vehicle_type_id ? 'selected' : ''); ?>><?php echo e($type->vehicle_type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Name</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_name" type="text" name="vehicle_name" value="<?php echo e(!empty($vehicle->vehicle_name)?$vehicle->vehicle_name:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Name" required>
                                        <?php $__errorArgs = ['vehicle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Slug</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_slug" type="text" name="slug" Value="<?php echo e(!empty($vehicle->vehicle_radom_slug)?$vehicle->vehicle_radom_slug:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Slug">
                                        <input type="hidden" name="vehicle_slug" value="<?php echo e($vehicle->vehicle_slug); ?>">
                                        <?php $__errorArgs = ['vehicle_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Base Location</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_company" type="text" name="vehicle_base_location" value="<?php echo e(!empty($vehicle->vehicle_base_location)?$vehicle->vehicle_base_location:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Base Location">
                                        <?php $__errorArgs = ['vehicle_base_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Make</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_make" type="text" name="vehicle_make" value="<?php echo e(!empty($vehicle->vehicle_make)?$vehicle->vehicle_make:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Make">
                                        <?php $__errorArgs = ['vehicle_make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Model</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_model" type="text" name="vehicle_model" value="<?php echo e(!empty($vehicle->vehicle_model)?$vehicle->vehicle_model:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Model">
                                        <?php $__errorArgs = ['vehicle_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Company</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_company" type="text" name="vehicle_company" value="<?php echo e(!empty($vehicle->vehicle_company)?$vehicle->vehicle_company:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Company">
                                        <?php $__errorArgs = ['vehicle_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Status</label><span style="color: red; margin:4px;">*</span>
                                        <select class="form-select digits" id="exampleFormControlSelect9" name="status">
                                            <option value="ACTIVE" <?php echo e($vehicle->status == "ACTIVE" ? 'selected':''); ?>>ACTIVE</option>
                                            <option value="INACTIVE" <?php echo e($vehicle->status == "INACTIVE" ? 'selected':''); ?>>INACTIVE</option>
                                        </select>
                                    </div>
                                    
                                </div>
                                
                                <div class="mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Description</label><span style="color: red; margin:4px;">*</span>
                                    <textarea class="form-control" id="vehicle_description" type="text" name="vehicle_description" value="" aria-describedby="emailHelp"><?php echo e(!empty($vehicle->vehicle_description)?$vehicle->vehicle_description:''); ?></textarea>
                                    <?php $__errorArgs = ['vehicle_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Thumbnail</label><span style="color: black; margin:4px;">(Optional)</span>
                                    <input class="form-control" id="vehicle_thumbnail" type="file" name="vehicle_thumbnail" aria-describedby="emailHelp" placeholder="Enter Vehicle Type">
                                    <?php $__errorArgs = ['vehicle_thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Multiple Vehicle Images</label><span style="color: black; margin:4px;">(Optional)</span>
                                    
                                    <input class="form-control" id="fileupload" name="vehicle_images[]" type="file" multiple="multiple" />
                                    <div id="dvPreview">
                                    <?php $__errorArgs = ['vehicle_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row mb-3">
                                    <?php $__currentLoopData = $vehicle_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-3 mb-3">
                                                <img src="<?php echo e(asset('uploads/vehicle/'.$img->image)); ?>" style="height:200px;width: 200px; margin: 10px; border: solid #0a55424f;" alt="">
                                                <a href="<?php echo e(route('admin.delete_vehicle_image',[$img->id,$img->vehicle_id])); ?>"><button type="button" class="btn btn-danger" style="margin-left: 9px;">remove</button></a>
                                            </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                
                                <hr>
                                <div class="mb-5">
                                    <span style="font-size: 138%;font-weight: 600;">Add Vehicle Attribute</span><span style="color: black; margin:4px;">(Optional)</span>
                                </div>
                                <div class="table-responsive mb-3">
                                    <table class="table table-bordered checkbox-td-width">
                                        <tbody>
                                            <tr>
                                                <th>Attribute Name</th>
                                                <th>Value</th>
                                            </tr>
                                            <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($attr->vehicle_attribute); ?></td>
                                                <td class="w-50">
                                                    <input type="hidden" name="attribute_id[]" value="<?php echo e($attr->attribute_id); ?>">
                                                    <input class="form-control input-primary" id="exampleFormControlInput1" type="text" name="vehicle_attr_val[]" value="<?php echo e($attr->value); ?>" placeholder="Add attribute value">
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <button class="btn btn-primary" type="submit">Update</button>
                                <button class="btn btn-secondary" type="reset">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script language="javascript" type="text/javascript">
    $(function () {
        $("#fileupload").change(function () {
            if (typeof (FileReader) != "undefined") {
                var dvPreview = $("#dvPreview");
                dvPreview.html("");
                var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                $($(this)[0].files).each(function () {
                    var file = $(this);
                    if (regex.test(file[0].name.toLowerCase())) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            var img = $("<img />");
                            img.attr("style", "height:200px;width: 200px; margin: 10px; border: solid #0a55424f;");
                            img.attr("src", e.target.result);
                            dvPreview.append(img);
                        }
                        reader.readAsDataURL(file[0]);
                    } else {
                        alert(file[0].name + " is not a valid image file.");
                        dvPreview.html("");
                        return false;
                    }
                });
            } else {
                alert("This browser does not support HTML5 FileReader.");
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/admin/vehicle/edit_vehicle.blade.php ENDPATH**/ ?>