

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-6">
                        <h3>Vehicle Type</h3>
                        <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item">Vehicle</li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle-type')); ?>">Vehicle Type</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/edit-vehicle-type')); ?>">Edit Vehicle Type</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                    <h5> Edit Vehicle Type </h5>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form class="theme-form" action="<?php echo e(url('/admin/update-vehicle-type',$type->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Title</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="" type="text" name="title" value="<?php echo e($type->title); ?>" aria-describedby="emailHelp" placeholder="Enter Title">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Meta Keyword</label><span style="color: black; margin:4px;">(Optional)</span>
                                    <input class="form-control" id="" type="text" name="meta_keyword" value="<?php echo e($type->meta_keyword); ?>" aria-describedby="emailHelp" placeholder="Enter Meta Keyword">
                                    <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-6 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Meta Description</label><span style="color: black; margin:4px;">(Optional)</span>
                                    <input class="form-control" id="" type="text" name="meta_description" value="<?php echo e($type->meta_description); ?>" aria-describedby="emailHelp" placeholder="Enter Service Name">
                                    <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="vehicle_type" type="text" name="vehicle_type" value="<?php echo e(!empty($type->vehicle_type)?$type->vehicle_type:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Type">
                                    <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-6 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type Slug</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="vehicle_type_slug" type="text" name="slug" value="<?php echo e(!empty($type->vehicle_slug)?$type->vehicle_slug:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Type Slug">
                                    <input type="hidden" name="vehicle_type_slug" value="<?php echo e($type->vehicle_type_slug); ?>">
                                    <?php $__errorArgs = ['vehicle_type_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Number of children</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="no_of_child" type="text" name="no_of_child" value="<?php echo e(!empty($type->price->no_of_child)?$type->price->no_of_child:''); ?>" aria-describedby="emailHelp" placeholder="Enter Number Of Children">
                                    <?php $__errorArgs = ['no_of_child'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-4 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Number of passengers</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="no_of_passenger" type="text" name="no_of_passengers" value="<?php echo e(!empty($type->price->no_of_passengers)?$type->price->no_of_passengers:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Passenger Capacity">
                                    <?php $__errorArgs = ['no_of_passengers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-4 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Number of suitcases</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="no_of_suitcases" type="text" name="no_of_suitcases" value="<?php echo e(!empty($type->price->no_of_suitcases)?$type->price->no_of_suitcases:''); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Suitcase Capacity">
                                    <?php $__errorArgs = ['no_of_suitcases'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type Image</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="type_image" type="file" name="vehicle_type_image" value="" aria-describedby="emailHelp" placeholder="Enter Vehicle Company">
                                    <?php $__errorArgs = ['vehicle_type_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-6 mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type Status</label><span style="color: red; margin:4px;">*</span>
                                    <select class="form-select digits" id="exampleFormControlSelect9" name="status">
                                        <option value="ACTIVE" <?php echo e($type->status == "ACTIVE"?'selected':''); ?>>ACTIVE</option>
                                        <option value="INACTIVE" <?php echo e($type->status == "INACTIVE"?'selected':''); ?>>INACTIVE</option>
                                    </select>
                                </div>
                            </div>
                            
                            <hr>
                                    <div class="mb-3">
                                        <span style="font-size: 138%;font-weight: 600;">Add Vehicle Price</span>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Base Price</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="base_price" value="<?php echo e(!empty($type->price->base_price)?$type->price->base_price:''); ?>" placeholder="Enter Base Price">
                                                <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Price Per Minute</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="price_per_min" value="<?php echo e(!empty($type->price->price_per_min)?$type->price->price_per_min:''); ?>" placeholder="Enter Price Per Minute">
                                                <?php $__errorArgs = ['price_per_min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Price Per Hour</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="price_per_hour" value="<?php echo e(!empty($type->price->price_per_hour)?$type->price->price_per_hour:''); ?>" placeholder="Enter Price Per Hour">
                                                <?php $__errorArgs = ['price_per_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Price Per KM</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="price_per_km" value="<?php echo e(!empty($type->price->price_per_km)?$type->price->price_per_km:''); ?>" placeholder="Enter Price Per Kilometer">
                                                <?php $__errorArgs = ['price_per_km'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Extra Waiting Time(Per min)</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="extra_waiting_time" value="<?php echo e(!empty($type->price->extra_waiting_time)?$type->price->extra_waiting_time:''); ?>" placeholder="Enter Extra Waiting Time">
                                            <?php $__errorArgs = ['extra_waiting_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Minimum Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="minimum_charge" value="<?php echo e(!empty($type->price->minimum_charge)?$type->price->minimum_charge:''); ?>" placeholder="Enter Minimum Vehicle Charge">
                                            <?php $__errorArgs = ['minimum_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Minimum Hour</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="minimum_hour" value="<?php echo e(!empty($type->price->minimum_hour)?$type->price->minimum_hour:''); ?>" placeholder="Enter Minimum Vehicle Hour">
                                            <?php $__errorArgs = ['minimum_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">International Airport Pickup Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="international_airport_pickup_charges" value="<?php echo e(!empty($type->price->international_airport_pickup_charges)?$type->price->international_airport_pickup_charges:''); ?>" placeholder="Enter Minimum Vehicle Hour">
                                            <?php $__errorArgs = ['international_airport_pickup_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Domestic Airport Pickup Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="domestic_airport_pickup_charges" value="<?php echo e(!empty($type->price->domestic_airport_pickup_charges)?$type->price->domestic_airport_pickup_charges:''); ?>" placeholder="Enter Extra Waiting Time">
                                            <?php $__errorArgs = ['domestic_airport_pickup_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Child Seat Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="child_seat_charges" value="<?php echo e(!empty($type->price->child_seat_charges)?$type->price->child_seat_charges:''); ?>" placeholder="Enter Minimum Vehicle Charge">
                                            <?php $__errorArgs = ['child_seat_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                    </div>
                            <div class="mb-3">
                                <label class="col-form-label pt-0" for="exampleInputEmail1">Description</label><span style="color: red; margin:4px;">*</span>
                                <textarea class="form-control" id="vehicle_type_description" type="text" name="vehicle_type_description" aria-describedby="emailHelp"><?php echo e(!empty($type->vehicle_type_description)?$type->vehicle_type_description:''); ?></textarea>
                                    <?php $__errorArgs = ['vehicle_type_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button class="btn btn-primary" type="submit">Update</button>
                            <a href="<?php echo e(route('admin.vehicle_type')); ?>"><button class="btn btn-secondary" type="button">Back</button></a>
                        </form>
                    </div>
                </div>
                </div>
            </div>
        </div> 
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/admin/vehicle/edit_vehicle_type.blade.php ENDPATH**/ ?>