

<?php $__env->startSection('content'); ?>
<section class="top-title">
    <div class="top-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="top-page-heading">
                        <h1>ACCORDION</h1>
                        <p class="sub-title">Shortcode Usage</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <li>
                            <a href="#">Home </a>
                        </li>
                        <li>
                            / Shortcode
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Top Title -->
<!-- Start Accordion Area -->
<section class="accordion-area">
    <div class="container">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="accordion">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-toggle">
                            <div class="toggle-title <?php echo e($faq->sno == 1?'active':''); ?>">
                                <?php echo e($faq->question); ?>

                                <span>
                                    <img src="<?php echo e(asset('frontend/images/icon/right-2.png')); ?>" alt="">
                                </span>
                            </div>
                            <div class="toggle-content">
                                <p>
                                    <?php echo $faq->answer; ?>

                                </p>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/pages/faq.blade.php ENDPATH**/ ?>