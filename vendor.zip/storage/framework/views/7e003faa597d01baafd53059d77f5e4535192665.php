

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-6">
                        <h3>Vehicle</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">Vehicle</li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle-type')); ?>">Vehicle Type</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5> Add Vehicle Type </h5>
                        </div>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong class><?php echo e($message); ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="mb-5">
                                <form class="theme-form" action="<?php echo e(url('/admin/add-vehicle-type')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-12 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Title</label><span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="" type="text" name="title" value="<?php echo e(old('title')); ?>" aria-describedby="emailHelp" placeholder="Enter Title">
                                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Meta Keyword</label><span style="color: black; margin:4px;">(Optional)</span>
                                            <input class="form-control" id="" type="text" name="meta_keyword" value="<?php echo e(old('meta_keyword')); ?>" aria-describedby="emailHelp" placeholder="Enter Meta Keyword">
                                            <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Meta Description</label><span style="color: black; margin:4px;">(Optional)</span>
                                            <input class="form-control" id="" type="text" name="meta_description" value="<?php echo e(old('meta_description')); ?>" aria-describedby="emailHelp" placeholder="Enter Service Name">
                                            <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type</label>
                                            <span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="vehicle_type" type="text" name="vehicle_type"
                                                value="<?php echo e(old('vehicle_type')); ?>" aria-describedby="emailHelp"
                                                placeholder="Enter Vehicle Type">
                                            <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <?php
                                        $random_val = Str::random(8);
                                        ?>
                                        <div class="col-6 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type
                                                Slug</label><span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="vehicle_type_slug" type="text"
                                                name="slug" value="<?php echo e($random_val); ?>"
                                                aria-describedby="emailHelp" placeholder="Enter Vehicle Type Slug">
                                            <?php $__errorArgs = ['vehicle_type_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type Image</label><span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="type_image" type="file" name="vehicle_type_image" value="<?php echo e(old('no_of_child')); ?>" placeholder="Enter Vehicle Company">
                                            <?php $__errorArgs = ['vehicle_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type Status</label><span style="color: red; margin:4px;">*</span>
                                            <select class="form-select digits" id="exampleFormControlSelect9" name="status">
                                                <option value="ACTIVE">ACTIVE</option>
                                                <option value="INACTIVE" selected>INACTIVE</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Number of children</label><span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="vehicle_company" type="text" name="no_of_child" value="<?php echo e(old('no_of_child')); ?>" aria-describedby="emailHelp" placeholder="Enter Number Of Children">
                                            <?php $__errorArgs = ['no_of_child'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-4 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Number of passengers</label><span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="no_of_passenger" type="text" name="no_of_passengers" value="<?php echo e(old('no_of_passengers')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Passenger Capacity">
                                            <?php $__errorArgs = ['no_of_passengers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-4 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Number of suitcases</label><span style="color: red; margin:4px;">*</span>
                                            <input class="form-control" id="no_of_suitcases" type="text" name="no_of_suitcases" value="<?php echo e(old('no_of_suitcases')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Suitcase Capacity">
                                            <?php $__errorArgs = ['no_of_suitcases'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="mb-3">
                                        <span style="font-size: 138%;font-weight: 600;">Add Vehicle Price</span>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Base Price</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="base_price" value="<?php echo e(old('base_price')); ?>" placeholder="Enter Base Price">
                                                <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Price Per Minute</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="price_per_min" value="<?php echo e(old('price_per_min')); ?>" placeholder="Enter Price Per Minute">
                                                <?php $__errorArgs = ['price_per_min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Price Per Hour</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="price_per_hour" value="<?php echo e(old('price_per_hour')); ?>" placeholder="Enter Price Per Hour">
                                                <?php $__errorArgs = ['price_per_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Price Per KM</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                                <input class="form-control" type="text" name="price_per_km" value="<?php echo e(old('price_per_km')); ?>" placeholder="Enter Price Per Kilometer">
                                                <?php $__errorArgs = ['price_per_km'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Extra Waiting Time(Per min)</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="extra_waiting_time" value="<?php echo e(old('extra_waiting_time')); ?>" placeholder="Enter Extra Waiting Time">
                                            <?php $__errorArgs = ['extra_waiting_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Minimum Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="minimum_charge" value="<?php echo e(old('minimum_charge')); ?>" placeholder="Enter Minimum Vehicle Charge">
                                            <?php $__errorArgs = ['minimum_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Minimum Hour</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="minimum_hour" value="<?php echo e(old('minimum_hour')); ?>" placeholder="Enter Minimum Vehicle Hour">
                                            <?php $__errorArgs = ['minimum_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">International Airport Pickup Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="international_airport_pickup_charges" value="<?php echo e(old('international_airport_pickup_charges')); ?>" placeholder="Enter Minimum Vehicle Hour">
                                            <?php $__errorArgs = ['international_airport_pickup_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Domestic Airport Pickup Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="domestic_airport_pickup_charges" value="<?php echo e(old('domestic_airport_pickup_charges')); ?>" placeholder="Enter Extra Waiting Time">
                                            <?php $__errorArgs = ['domestic_airport_pickup_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label class="col-form-label pt-0" for="exampleInputEmail1">Child Seat Charge</label><span style="color: red; margin:4px;">*</span>
                                            <div class="input-group"><span class="input-group-text">$</span>
                                            <input class="form-control" type="text" name="child_seat_charges" value="<?php echo e(old('child_seat_charges')); ?>" placeholder="Enter Minimum Vehicle Charge">
                                            <?php $__errorArgs = ['child_seat_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Description</label><span style="color: red; margin:4px;">*</span>
                                        <textarea class="form-control" id="vehicle_type_description" type="text" name="vehicle_type_description"
                                            value="<?php echo e(old('vehicle_type_description')); ?>" aria-describedby="emailHelp"></textarea>
                                        <?php $__errorArgs = ['vehicle_type_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                    <button class="btn btn-secondary" type="reset">Cancel</button>
                                </form>
                            </div>
                            <div class="table-responsive">
                                <table class="stripe" id="example-style-8">
                                    <thead>
                                        <tr>
                                            <th>Thumbnail</th>
                                            <th>Vehicle Type</th>
                                            <th>Slug</th>
                                            <th>Description</th>
                                            <th>Number of passengers and suitcases</th>
                                            <th>Net Prices</th>
                            
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><img src="<?php echo e(asset('uploads/vehicle_type/'.$type->vehicle_type_image)); ?>" alt="" srcset="" style="height: 188px; 270px;"></td>
                                                <td><?php echo e(!empty($type->vehicle_type)?$type->vehicle_type:'NA'); ?></td>
                                                <td><?php echo e(!empty($type->vehicle_type_slug)?$type->vehicle_type_slug:'NA'); ?></td>
                                                <td><?php echo e(!empty($type->vehicle_type_description)?$type->vehicle_type_description:'NA'); ?></td>
                                                <td>
                                                    No. of Passengers: <?php echo e(!empty($type->price->no_of_child)?$type->price->no_of_child:'NA'); ?><br/>
                                                    No. of Children: <?php echo e(!empty($type->price->no_of_passengers)?$type->price->no_of_passengers:'NA'); ?><br/>
                                                    No. of Suitcases: <?php echo e(!empty($type->price->no_of_suitcases)?$type->price->no_of_suitcases:'NA'); ?>

                                                </td>
                                                <td>
                                                    Base Price: $<?php echo e(!empty($type->price->base_price)?$type->price->base_price:'NA'); ?><br/>
                                                    Price Per Minute: $<?php echo e(!empty($type->price->price_per_min)?$type->price->price_per_min:'NA'); ?><br/>
                                                    Price Per Hour: $<?php echo e(!empty($type->price->price_per_hour)?$type->price->price_per_hour:'NA'); ?><br/>
                                                    Price Per KM: $<?php echo e(!empty($type->price->price_per_km)?$type->price->price_per_km:'NA'); ?><br/>
                                                    Extra Waiting Time(Price Per min): $<?php echo e(!empty($type->price->extra_waiting_time)?$type->price->extra_waiting_time:'NA'); ?><br/>
                                                    Minimum Vehicle Charge: $<?php echo e(!empty($type->price->minimum_charge)?$type->price->minimum_charge:'NA'); ?><br/>
                                                    Minimum Vehicle Hour Booking: $<?php echo e(!empty($type->price->minimum_hour)?$type->price->minimum_hour:'NA'); ?><br/>
                                                </td>
                                                
                                                <td>
                                                    <a href="<?php echo e(url('admin/edit-vehicle-type', $type->id)); ?>"><button
                                                            class="btn btn-warning"><i class="fa fa-pencil"></i></button>
                                                    </a>
                                                    <a href="<?php echo e(url('admin/delete-vehicle-type', $type->id)); ?>"><button
                                                            class="btn btn-danger"><i class="fa fa-trash"></i></button></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Thumbnail</th>
                                            <th>Vehicle Type</th>
                                            <th>Slug</th>
                                            <th>Description</th>
                                            <th>Number of passengers and suitcases</th>
                                            <th>Net Prices</th>
                                            <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/admin/vehicle/vehicle_type.blade.php ENDPATH**/ ?>