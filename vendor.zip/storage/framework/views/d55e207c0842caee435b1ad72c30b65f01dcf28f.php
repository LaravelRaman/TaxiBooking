

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-6">
                        <h3>Add Vehicle</h3>
                        <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item">Vehicle</li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle')); ?>">Vehicles</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/vehicle-type')); ?>">Add Vehicle</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-6">
                                    <h5> Add Vehicle </h5>
                                </div>
                                <div class="col-6">
                                    <a href="<?php echo e(url('admin/vehicle')); ?>"><button class="btn btn-danger" style="float:right;">Back</button></a>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <form class="theme-form" action="<?php echo e(url('/admin/add-vehicle')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Type</label><span style="color: red; margin:4px;">*</span>
                                        <select class="form-control" id="vehicle_type" type="text" name="vehicle_type" aria-describedby="emailHelp" placeholder="Enter Vehicle Name">
                                            <option value="">-- no type selected --</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->vehicle_type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Name</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_name" type="text" name="vehicle_name" value="<?php echo e(old('vehicle_name')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Name">
                                        <?php $__errorArgs = ['vehicle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <?php 
                                        $random_val = Str::random(8);
                                    ?>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Slug</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_slug" type="text" name="slug" Value="<?php echo e($random_val); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Slug">
                                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Base Location</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_company" type="text" name="vehicle_base_location" value="<?php echo e(old('vehicle_base_location')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Base Location">

                                        
                                        <?php $__errorArgs = ['vehicle_base_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Make</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_make" type="text" name="vehicle_make" value="<?php echo e(old('vehicle_make')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Make">
                                        <?php $__errorArgs = ['vehicle_make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Model</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_model" type="text" name="vehicle_model" value="<?php echo e(old('vehicle_model')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Model">
                                        
                                        <?php $__errorArgs = ['vehicle_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Company</label><span style="color: red; margin:4px;">*</span>
                                        <input class="form-control" id="vehicle_company" type="text" name="vehicle_company" value="<?php echo e(old('vehicle_company')); ?>" aria-describedby="emailHelp" placeholder="Enter Vehicle Company">
                                        <?php $__errorArgs = ['vehicle_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Status</label><span style="color: red; margin:4px;">*</span>
                                        <select class="form-select digits" id="exampleFormControlSelect9" name="status">
                                            <option value="ACTIVE">ACTIVE</option>
                                            <option value="INACTIVE" selected>INACTIVE</option>
                                        </select>
                                    </div>
                                    
                                </div>
                                
                                <div class="mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Description</label><span style="color: red; margin:4px;">*</span>
                                    <textarea class="form-control" id="vehicle_description" type="text" name="vehicle_description" aria-describedby="emailHelp"><?php echo e(old('vehicle_description')); ?></textarea>
                                    <?php $__errorArgs = ['vehicle_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Vehicle Thumbnail</label><span style="color: red; margin:4px;">*</span>
                                    <input class="form-control" id="vehicle_thumbnail" type="file" name="vehicle_thumbnail" aria-describedby="emailHelp" placeholder="Enter Vehicle Type">
                                    <?php $__errorArgs = ['vehicle_thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="col-form-label pt-0" for="exampleInputEmail1">Multiple Vehicle Images</label><span style="color: red; margin:4px;">*</span>
                                    
                                    <input class="form-control" id="fileupload" name="vehicle_images[]" type="file" multiple="multiple" />
                                    <div id="dvPreview">
                                    <?php $__errorArgs = ['vehicle_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <hr>
                                <div class="mb-5">
                                    <span style="font-size: 138%;font-weight: 600;">Add Vehicle Attribute</span><span style="color: black; margin:4px;">(Optional)</span>
                                </div>
                                <div class="table-responsive mb-3">
                                    <table class="table table-bordered checkbox-td-width">
                                        <tbody>
                                            <tr>
                                                <th>Attribute Name</th>
                                                <th>Value</th>
                                            </tr>
                                            <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($attr->vehicle_attribute); ?></td>
                                                <td class="w-50">
                                                    <input type="hidden" name="attribute_id[]" value="<?php echo e($attr->id); ?>">
                                                    <input class="form-control input-primary" id="exampleFormControlInput1" type="text" name="vehicle_attr_val[]" placeholder="Add attribute value">
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div> 
                                <hr>
                                
                                <button class="btn btn-primary" type="submit">Submit</button>
                                <button class="btn btn-secondary" type="reset">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script language="javascript" type="text/javascript">
    $(function () {
        $("#fileupload").change(function () {
            if (typeof (FileReader) != "undefined") {
                var dvPreview = $("#dvPreview");
                dvPreview.html("");
                var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                $($(this)[0].files).each(function () {
                    var file = $(this);
                    if (regex.test(file[0].name.toLowerCase())) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            var img = $("<img />");
                            img.attr("style", "height:200px;width: 200px; margin: 10px; border: solid #0a55424f;");
                            img.attr("src", e.target.result);
                            dvPreview.append(img);
                        }
                        reader.readAsDataURL(file[0]);
                    } else {
                        alert(file[0].name + " is not a valid image file.");
                        dvPreview.html("");
                        return false;
                    }
                });
            } else {
                alert("This browser does not support HTML5 FileReader.");
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prodrive\resources\views/admin/vehicle/add_vehicle.blade.php ENDPATH**/ ?>